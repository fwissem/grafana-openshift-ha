# Changelog

## [2.5.1](https://github.com/grafana/metrics-drilldown/compare/v2.5.0...v2.5.1) (2026-08-24)


### 🐛 Bug Fixes

* **deps:** bump pnpm overrides for CVE remediation ([6d7a43f](https://github.com/grafana/metrics-drilldown/commit/6d7a43f03ac743498f485c3efa908c98f728680f))
* **deps:** resolve pnpm audit vulnerabilities ([#1392](https://github.com/grafana/metrics-drilldown/issues/1392)) ([6d7a43f](https://github.com/grafana/metrics-drilldown/commit/6d7a43f03ac743498f485c3efa908c98f728680f))
* histogram breakdown values bug in applying function ([#1401](https://github.com/grafana/metrics-drilldown/issues/1401)) ([a9e9c62](https://github.com/grafana/metrics-drilldown/commit/a9e9c62e6eeef9647e6d1cd97cde830ebff219ec))
* native histogram no data bug ([#1380](https://github.com/grafana/metrics-drilldown/issues/1380)) ([8e9d6b5](https://github.com/grafana/metrics-drilldown/commit/8e9d6b5613abfc7ee5a6c1356baead437cc9bab7))
* show native histogram label breakdown correctly ([#1394](https://github.com/grafana/metrics-drilldown/issues/1394)) ([9582187](https://github.com/grafana/metrics-drilldown/commit/9582187327a49107434489c42301e5a326199234))
* use derived metric type in config presets to fix native histogram bug ([#1396](https://github.com/grafana/metrics-drilldown/issues/1396)) ([b1b9831](https://github.com/grafana/metrics-drilldown/commit/b1b983113050c8e22e5a446ece6bf432e872597e))


### 🧹 Chore

* **deps:** Update dependency @grafana/plugin-e2e to v3.11.0 ([#1382](https://github.com/grafana/metrics-drilldown/issues/1382)) ([471f506](https://github.com/grafana/metrics-drilldown/commit/471f5068621273e254a3a03fd5e50497d007a0f7))
* **deps:** Update dependency @testing-library/jest-dom to v7 ([#1387](https://github.com/grafana/metrics-drilldown/issues/1387)) ([dec381f](https://github.com/grafana/metrics-drilldown/commit/dec381f5211c5366e5c5b708e08647a5f919cbcd))
* **deps:** Update GitHub Actions to v7 ([#1390](https://github.com/grafana/metrics-drilldown/issues/1390)) ([7cedaaf](https://github.com/grafana/metrics-drilldown/commit/7cedaafc24e122573bebfb847d880a067401db28))
* **deps:** update grafana/plugin-ci-workflows/ci-cd-workflows action to v11.1.0 ([#1391](https://github.com/grafana/metrics-drilldown/issues/1391)) ([47a4a81](https://github.com/grafana/metrics-drilldown/commit/47a4a81471df7e364186407668badf99b71505f0))
* **deps:** Update TypeScript and linting ([#1383](https://github.com/grafana/metrics-drilldown/issues/1383)) ([39d8161](https://github.com/grafana/metrics-drilldown/commit/39d816110e2a9ea31d5651a3f7f31165db89d906))
* remove bottom border between filters and quicksearch ([#1400](https://github.com/grafana/metrics-drilldown/issues/1400)) ([c560967](https://github.com/grafana/metrics-drilldown/commit/c5609675e1655de38fa005332c6eeb48e5b20bd9))
* update release-please ([#1399](https://github.com/grafana/metrics-drilldown/issues/1399)) ([1e841db](https://github.com/grafana/metrics-drilldown/commit/1e841dbf3a292ff0c33c5e24e230156ce27122ff))

## [2.5.0](https://github.com/grafana/metrics-drilldown/compare/v2.4.0...v2.5.0) (2026-08-13)


### 🎉 Features

* **sea-of-metrics:** tag metric_selected with the firing-alerts cohort ([#1375](https://github.com/grafana/metrics-drilldown/issues/1375)) ([52379fa](https://github.com/grafana/metrics-drilldown/commit/52379fa502b397ade8a3fc7caf9d21dbf7724d90))


### 🧹 Chore

* **deps:** add pnpm supply-chain security settings ([#1353](https://github.com/grafana/metrics-drilldown/issues/1353)) ([ff16f76](https://github.com/grafana/metrics-drilldown/commit/ff16f76c4edd1a92ec36f07c9d8f5d39121dbeca))
* **deps:** combine Renovate dependency updates ([#1377](https://github.com/grafana/metrics-drilldown/issues/1377)) ([2a18039](https://github.com/grafana/metrics-drilldown/commit/2a180397a340e90d0aaf931633fd6b5e8e300d9e))
* **faro:** duplicate rudderstack events as faro events and enhance instrumentation ([#1366](https://github.com/grafana/metrics-drilldown/issues/1366)) ([6594c07](https://github.com/grafana/metrics-drilldown/commit/6594c071bb7a04b99b72adb410e9674a01f118bd))
* **release-please:** show chores in changelog ([#1379](https://github.com/grafana/metrics-drilldown/issues/1379)) ([38ea9dd](https://github.com/grafana/metrics-drilldown/commit/38ea9dd39d958b2ed3574f74e214d0fd64952331))

## [2.4.0](https://github.com/grafana/metrics-drilldown/compare/v2.3.1...v2.4.0) (2026-08-04)


### 🎉 Features

* **sea-of-metrics:** make firing-alerts flag an Odin A/B test experiment ([#1357](https://github.com/grafana/metrics-drilldown/issues/1357)) ([5739295](https://github.com/grafana/metrics-drilldown/commit/57392958b30b20f92a35358c9b6405fd1bb6241f))


### 🐛 Bug Fixes

* **deps:** bump pnpm overrides for CVE remediation ([6e971a8](https://github.com/grafana/metrics-drilldown/commit/6e971a8aa8285fcde6ec6a47f345f2c797da91ff))
* **deps:** resolve pnpm audit vulnerabilities ([#1360](https://github.com/grafana/metrics-drilldown/issues/1360)) ([3c4c3ba](https://github.com/grafana/metrics-drilldown/commit/3c4c3ba30aa27cb288449dc750afd5da0769bd62))
* **deps:** resolve pnpm audit vulnerabilities ([#1367](https://github.com/grafana/metrics-drilldown/issues/1367)) ([6e971a8](https://github.com/grafana/metrics-drilldown/commit/6e971a8aa8285fcde6ec6a47f345f2c797da91ff))


### 📝 Documentation

* correct Metrics Drilldown UI labels and behavior claims ([#1362](https://github.com/grafana/metrics-drilldown/issues/1362)) ([857d798](https://github.com/grafana/metrics-drilldown/commit/857d798cf7c5d98b5028f0f61aebb49e7fe681cb))


### 🧪 Tests

* **e2e:** force queryLibrary off so saved-queries specs run on nightly ([#1364](https://github.com/grafana/metrics-drilldown/issues/1364)) ([eed46f6](https://github.com/grafana/metrics-drilldown/commit/eed46f6efcdaf51b963726d504a37c741eb452ba))

## [2.3.1](https://github.com/grafana/metrics-drilldown/compare/v2.3.0...v2.3.1) (2026-07-28)


### 🐛 Bug Fixes

* **deps:** bump pnpm overrides for CVE remediation ([d52aced](https://github.com/grafana/metrics-drilldown/commit/d52acedbb4407b68284d624c33a778500d77f6c8))
* **deps:** resolve pnpm audit vulnerabilities ([#1352](https://github.com/grafana/metrics-drilldown/issues/1352)) ([d52aced](https://github.com/grafana/metrics-drilldown/commit/d52acedbb4407b68284d624c33a778500d77f6c8))

## [2.3.0](https://github.com/grafana/metrics-drilldown/compare/v2.2.0...v2.3.0) (2026-07-21)


### 🎉 Features

* **list-controls:** add "Has firing alerts" filter chip to metrics toolbar ([#1281](https://github.com/grafana/metrics-drilldown/issues/1281)) ([48c8503](https://github.com/grafana/metrics-drilldown/commit/48c850395f3a44bfd853486219350efa07483562))
* **sea-of-metrics:** Phase 1 — firing alerts sort, visual badges, and instrumentation ([#1342](https://github.com/grafana/metrics-drilldown/issues/1342)) ([fc33fca](https://github.com/grafana/metrics-drilldown/commit/fc33fca923330e8b3d837aad8dfc44bef8292f4c))


### 🐛 Bug Fixes

* **deps:** resolve pnpm audit vulnerabilities ([#1347](https://github.com/grafana/metrics-drilldown/issues/1347)) ([c85c02c](https://github.com/grafana/metrics-drilldown/commit/c85c02ce5547a157ae7dd6e9166fe4d9fc9d09a0))
* **faro:** deduplicate InlineBanner error reporting to prevent SLO breach ([#1349](https://github.com/grafana/metrics-drilldown/issues/1349)) ([6e207e7](https://github.com/grafana/metrics-drilldown/commit/6e207e7c357349b4897972a3c90d7de374272091))

## [2.2.0](https://github.com/grafana/metrics-drilldown/compare/v2.1.0...v2.2.0) (2026-07-02)


### 🎉 Features

* **sourceMetrics:** add metricType per-entry override ([#1320](https://github.com/grafana/metrics-drilldown/issues/1320)) ([6b1064b](https://github.com/grafana/metrics-drilldown/commit/6b1064b2477e6a13407b0fce69886377f7639078))
* **SourceMetrics:** kg source metrics custom function ([#1316](https://github.com/grafana/metrics-drilldown/issues/1316)) ([c126a33](https://github.com/grafana/metrics-drilldown/commit/c126a3371231f6e21153d24cbae2c51853acc38a))
* **SourceMetrics:** support kg ratio queries ([#1338](https://github.com/grafana/metrics-drilldown/issues/1338)) ([7ed2371](https://github.com/grafana/metrics-drilldown/commit/7ed23712573ca4538c7314500e41496f82b95146))


### 🐛 Bug Fixes

* **deps:** bump dompurify override to ^3.4.11 ([#1322](https://github.com/grafana/metrics-drilldown/issues/1322)) ([7ec03e3](https://github.com/grafana/metrics-drilldown/commit/7ec03e3d6bfecee156da13a85ffeaeb3d9ce2c86))
* **deps:** bump dompurify override to ^3.4.11 for CVE remediation ([7ec03e3](https://github.com/grafana/metrics-drilldown/commit/7ec03e3d6bfecee156da13a85ffeaeb3d9ce2c86))
* **deps:** upgrade @grafana/* packages to 13.1.0 to fix compatibility check ([#1337](https://github.com/grafana/metrics-drilldown/issues/1337)) ([156bc3b](https://github.com/grafana/metrics-drilldown/commit/156bc3be2efb66ae583d6c146f50daf0f95c7c7e))


### 📝 Documentation

* Add GenAI policy, contributor guide updates and issue templates ([#1339](https://github.com/grafana/metrics-drilldown/issues/1339)) ([604ea20](https://github.com/grafana/metrics-drilldown/commit/604ea20dbe42a7d4a2485ed3144b663f3449c346))

## [2.1.0](https://github.com/grafana/metrics-drilldown/compare/v2.0.7...v2.1.0) (2026-06-16)


### 🎉 Features

* **sorter:** add fetchFiringAlertMetrics data layer for firing alert rules ([#1273](https://github.com/grafana/metrics-drilldown/issues/1273)) ([42add87](https://github.com/grafana/metrics-drilldown/commit/42add87b489f46df87e1b7f8adc2583355ea9f6e))
* **sourceMetrics:** per-metric `customRateInterval` override in KG source metrics component ([#1257](https://github.com/grafana/metrics-drilldown/issues/1257)) ([f9ed7cb](https://github.com/grafana/metrics-drilldown/commit/f9ed7cb0e7f9d7792391b97d81e8194ba5dae146))


### 🐛 Bug Fixes

* **cve:** bump react-router to 6.30.4 (GHSA-2j2x-hqr9-3h42) ([#1309](https://github.com/grafana/metrics-drilldown/issues/1309)) ([547b2bb](https://github.com/grafana/metrics-drilldown/commit/547b2bb2a955f446d0346eb89f54d7c1854cc809))
* **cve:** override vulnerable transitive deps ([#1280](https://github.com/grafana/metrics-drilldown/issues/1280)) ([42fdcb7](https://github.com/grafana/metrics-drilldown/commit/42fdcb7d734bd443525217a9da75d0c06b9b3d3e))
* **deps:** resolve all pnpm audit vulnerabilities ([#1319](https://github.com/grafana/metrics-drilldown/issues/1319)) ([237b2bc](https://github.com/grafana/metrics-drilldown/commit/237b2bc7715634879651b013aba2ee15d721d2fa))
* **i18n:** use fromJSON output for Crowdin token from vault secrets ([#1308](https://github.com/grafana/metrics-drilldown/issues/1308)) ([ea2d1de](https://github.com/grafana/metrics-drilldown/commit/ea2d1dea83f6793fecc8f01a238f5bfc49362869)), closes [#1307](https://github.com/grafana/metrics-drilldown/issues/1307)
* use prerelease-inclusive semver ranges in grafanaDependency ([#1313](https://github.com/grafana/metrics-drilldown/issues/1313)) ([7661216](https://github.com/grafana/metrics-drilldown/commit/76612165d9b72d9b90cbeb6183d41f075e58681d))


### 🏗️ Builds

* **pnpm:** upgrade from v10 to v11 ([#1272](https://github.com/grafana/metrics-drilldown/issues/1272)) ([1a2e55e](https://github.com/grafana/metrics-drilldown/commit/1a2e55ec3f8535ce51a5c6f7a50c6cac88289415))


### 🤖 Continuous Integrations

* **release-please:** add release please ([#1310](https://github.com/grafana/metrics-drilldown/issues/1310)) ([5cfd4b0](https://github.com/grafana/metrics-drilldown/commit/5cfd4b07d259d91026c1fe7a24349e7804c74926))

## 2.0.7

##### Chores

*  add enrichment for conversion measurement (#1251) (0fb2aecc)
*  make tree filters GA, remove feature toggle (#1245) (a732ac61)

##### Bug Fixes

* **cve:**
  *  override protobufjs to patched versions (#1249) (6c768df8)
  *  override fast-uri (#1243) (5a2f2eb7)

##### Refactors

* **error-handling:**
  *  add exposed component + route-level error boundaries (#1253) (e0e7d5ef)
  *  replace global error capture with scoped React Error Boundary (#1244) (6d56d7b6)


## 2.0.6

##### Chores

* **extensions:**  use group type from grafana data (#1231) (9742b9d0)
*  skip attestation for forks (#1241) (ae70ad30)
* **deps:**  Update dependency @grafana/plugin-e2e to v3.6.1 (#1232) (ff280ca4)

##### Bug Fixes

* **ci/cd:**  add permissions to workflow (#1240) (c77e7641)
* **deps:**  override postcss to >=8.5.10 for CVE fix (#1239) (f45b7bf7)


## 2.0.5

##### Bug Fixes

* **ci:**  bump plugin-ci-workflows to v7.3.1 (#1230) (2dcd73ad)


## 2.0.4

##### Chores

* **deps:**
  *  fix CVEs (#1220) (e3cfa78e)
  *  update grafana/plugin-ci-workflows/ci-cd-workflows action to v7.1.0 (#1218) (95de2fba)
  *  Update docker.io/prom/prometheus Docker tag to v3.11.2 (#1217) (3f17a74e)
  *  Update dependency sass to v1.99.0 (#1216) (5fc52786)
  *  Update dependency @react-aria/utils to v3.34.0 (#1215) (86cd25c6)
  *  Update dependency @prometheus-io/lezer-promql to ^0.311.0 (#1214) (c674dce0)
  *  Update dependency @grafana/plugin-e2e to v3.6.0 (#1213) (a3d2076d)
  *  Update pnpm to v10.33.2 (#1212) (1bdb51fc)
  *  Update dependency brace-expansion@^1 to v5 (#1185) (74991fdb)
  *  Update Build tools (#1201) (b298eb27)
  *  Update dependency picomatch@^2 to v4 (#1186) (01e46bbf)
  *  Update dependency dotenv to v17.4.2 (#1183) (ff18f618)
  *  Update dependency @playwright/test to v1.59.1 (#1182) (49900bd1)
  *  Update dependency uuid to v14 [SECURITY] (#1210) (2e6bfa76)
  *  Update pnpm/action-setup action to v5 (#1188) (048c7ba8)
  *  Update dependency @types/node to v24.12.2 (#1202) (fe2ec294)
*  add mise.toml and align CI node version (#1211) (a3e8254a)

##### Bug Fixes

* **ci:**  consolidate CI/CD into single workflow (#1229) (e09c0678)
* **native-histogram:**  rely solely on data frames for native histogram detection (#1207) (cce239fa)
*  test __name__ patch to use in components (#1226) (ad8a3909)
*  type InlineBanner error prop as unknown to prevent crash (#1225) (effce5ed)
*  filter Safari extension errors that crash the app (#1223) (fe0b63a9)
*  ignore new resize observer error that causes fatal crash (#1219) (2c208dec)
* **provisioning:**  use Docker service name for Prometheus datasource URL (#1222) (1ab1c083)


## 2.0.3

##### Chores

* **webpack:**  fix Immutable.js build warnings (#1209) (61e4113c)
*  bump @bsull/augurs to 0.10.2 (#1203) (a6fc62f6)
*  update media queries to use container queries (#1193) (842c7fa8)

##### Bug Fixes

* **adhocFiltersVariable:**  add patch in query runner to remove __name__ filter in queries (#1205) (a71070f0)
*  ts error and run prettier (#1206) (269861f1)
*  prevent native histogram double-rebuild race condition (#1113) (10b55a9f)
* **deps:**  resolve pnpm audit CVEs (protobufjs, dompurify, protocol-buffers-schema) (#1204) (db4d0989)
* **kg:**  change warning annotation color from orange to yellow (#1191) (67e8914f)

##### Other Changes

*  Download translations from Crowdin (#1208) (5965657e)
*  Download translations from Crowdin (#1198) (1373adc0)


## 2.0.2

##### Chores

- **deps:**
  - Update dependency @grafana/plugin-e2e to v3.4.12 (#1181) (b0f171a1)
  - Update TypeScript and linting (#1184) (181c6fc5)
- bump @grafana packages toward 13.0.0 (#1196) (a76ec552)

##### Bug Fixes

- update related metrics select button to secondary variant (#1192) (912f6f84)

##### Other Changes

- Download translations from Crowdin (#1197) (1513d73b)
- Download translations from Crowdin (#1194) (7849d423)

##### Performance Improvements

- **i18n:** prevent loading en-US translations at runtime (#1195) (905d7bd1)

## 2.0.1

##### Chores

- **deps:**
  - Pin dependencies (#1168) (ceb93c7c)
  - update grafana/plugin-ci-workflows/ci-cd-workflows action to v7.0.0 (#1161) (12a1c041)
  - Update actions/upload-artifact action to v7 (#1157) (140fbe3a)
  - Update docker.io/prom/prometheus Docker tag to v3.10.0 (#1155) (aecd1fee)
  - Update Build tools (#1169) (c9b845bf)
  - Update dependency @grafana/plugin-e2e to v3.4.10 (#1152) (f30a3ef9)
  - Update TypeScript and linting (#1170) (2a8b7df4)
  - Update pnpm to v10.33.0 (#1171) (55dd1db3)
  - Update dependency minimatch@^9 to v10 (#1159) (f25dd9fc)
  - Update TypeScript and linting (#1154) (5164b27d)
  - Update pnpm to v10.32.1 (#1156) (6ed18a4b)
  - Update dependency webpack-cli to v7 (#1160) (90607a85)
  - combine all Renovate dependency updates (#1150) (6863852c)
- assign @grafana/docs-metrics as codeowners for docs (#1164) (39871b0d)
- remove disabled Settings section from sidebar (#1143) (b776da2e)
- add GitNexus dev tooling (#1147) (304e8d33)

##### Documentation Changes

- Update menu title and weight in \_index.md (#1178) (cd9e487a)

##### New Features

- **units:** expand unit detection with hardware, energy, and ratio s… (#1176) (5b2a73f1)
- add Knowledge Graph annotation overlays (#1173) (4e384aa0)

##### Bug Fixes

- add entry in CODEOWNERS for the docs (#1180) (c0349175)
- publish to catalog workflow (#1174) (d75c1d95)
- pin versions to fix `pnpm audit` (#1166) (85ced206)
- populate datasource filter in LoadQueryScene (#1139) (deb3cd77)
- **deps:**
  - resolve lodash CVEs (CVE-2026-4800, CVE-2026-2950) (#1177) (904f7093)
  - resolve `pnpm audit` vulnerabilities in `serialize-javascr… (#1172) (d3993afd)
  - override flatted and undici to resolve Trivy CVEs (#1151) (8ee55901)
- **goff:** use subpath in the openfeature api url (#1167) (44e977e1)

##### Other Changes

- Download translations from Crowdin (#1179) (9ec556b1)
- Download translations from Crowdin (#1163) (5bba679d)

##### Performance Improvements

- Lazy-load Faro in module.tsx (#1162) (f6f6f655)

## 2.0.0

##### Chores

- upgrade to React 19 for Grafana 13 compatibility (#1128) (dcc4215a)

##### Documentation Changes

- Update docs for latest UI changes (#1141) (d36c5ee4)

##### Bug Fixes

- **ci:** add pull-requests read permission to CD workflow (#1149) (86fac9e2)

## 1.0.34

##### Chores

- **deps:**
  - Update dependency copy-webpack-plugin to v14 (#1120) (41869e6c)
  - Update dependency @react-aria/utils to v3.33.1 (#1119) (745d8944)
  - Update TypeScript and linting (major) (#1111) (1f06969f)
  - Update pnpm to v10.30.3 (#1107) (5ce4565f)

##### New Features

- **extensions:** migrate DashboardPanelMenu from category to group API (#1121) (2350e210)

##### Bug Fixes

- breadcrumb navigation issue (#1126) (4261601b)
- filter native histogram zero-bucket-only frames to prevent heatmap crash (#1127) (0d847bdb)
- resolve CVE-2026-3449 (@tootallnate/once) (#1125) (a8908a1c)
- resolve high CVEs in transitive dependencies (#1122) (9eed652c)
- filter "" and '' values as empty matchers like `label!=""` (#1118) (ebe53941)

## 1.0.33

##### New Features

- fix saved queries instrumentation, fix dead path events (#1115) (3801bff6)
- add create alert event for tracking (#1114) (e44b28d2)

##### Bug Fixes

- filter empty native histogram heatmap frames to prevent OOM crash (#1116) (d491acaf)

##### Other Changes

- Download translations from Crowdin (#1103) (755a5192)

## 1.0.32

##### Chores

- **i18n:** Expose all supported languages in plugin.json (#1096) (cb9f88e0)
- update grafana dependencies to v12.4.0 (#1098) (52b88597)
- **deps:**
  - Lock file maintenance (#1094) (9ec9e703)
  - Update dependency css-loader to v7.1.4 (#1090) (1b4a293a)
  - Update dependency @grafana/plugin-e2e to v3.3.2 (#1089) (5a880cae)
  - Update dependency glob to v13.0.6 (#1091) (ccd140d6)
  - Update TypeScript and linting (#1093) (c924cce1)
  - Update pnpm to v10.30.1 (#1092) (b160d37b)

##### New Features

- add saved queries (#1064) (14ba8ac2)
- show dashboard sort limit warning (#1088) (2f2a6150)
- expose embeded metrics component (#782) (0c726307)

##### Bug Fixes

- native histogram can sum by le without effect (#1101) (b675b97e)

##### Other Changes

- Download translations from Crowdin (#1087) (7597632d)

## 1.0.31

##### Chores

- **docker:** support appending feature toggles and fix alert rules (#1083) (17e410e6)
- **deps:**
  - Update dependency glob to v13.0.3 (#1077) (49253934)
  - Update dependency @types/node to v24.10.13 (#1075) (cf871a47)
  - Update dependency dotenv to v17.3.1 (#1076) (be33a6da)
  - Update dependency webpack to v5.105.2 (#1078) (3e356546)
  - Update dependency @playwright/test to v1.58.2 (#1074) (da5349e2)
  - Update TypeScript and linting (#1080) (283a2720)
  - Update pnpm to v10.29.3 (#1079) (7470035c)
  - Update dependency @grafana/plugin-e2e to v3.3.0 (#1073) (eedbcf51)
- remove Docker-based Playwright in favor of node-based execution (#1065) (b982b661)

##### Documentation Changes

- remove Docker-based screenshot testing documentation (#1072) (e584da65)

##### Other Changes

- Download translations from Crowdin (#1069) (071cc911)

## 1.0.30

##### Chores

- **deps:**
  - Update actions/checkout digest to de0fac2 (#1049) (2c26f3ec)
  - Update dependency @react-aria/utils to v3.33.0 (#1054) (699d38c2)
  - Update dependency glob to v13.0.1 (#1052) (c8aeb0bd)
  - Update dependency @grafana/plugin-e2e to v3.2.1 (#1053) (a486bef1)
  - Update dependency @playwright/test to v1.58.1 (#1050) (9d4a4b78)
  - Update Build tools (#1055) (49a20d88)
  - Update Node.js to v24 (#1056) (a9b100c6)
  - Update docker.io/prom/prometheus Docker tag to v3.9.1 (#1005) (8fddce3c)
  - Update dependency glob to v13 (#1008) (e41c5c8a)
  - Update GitHub Actions to v6 (major) (#1011) (7d64b118)
  - Update dependency p-limit to v7 (#1010) (e6064e2f)
  - Update dependency globals to v17 (#1009) (e4ed1075)
  - Update dependency dotenv to v17 (#1007) (478b5946)
  - Update dependency @react-aria/utils to v3.32.0 (#1004) (9fefd1cb)
  - Update TypeScript and linting (#1006) (eb1f8596)
  - Update Build tools (#1003) (ec5fc881)
  - Update GitHub Actions (#866) (b018293f)
  - Update Build tools (major) (#920) (04ab0c97)
  - Update TypeScript and linting (#918) (c726d3d1)
  - Update Build tools (#876) (7cadc84c)
- updates nvmrc node version to lts (#1060) (0c91fa7a)
- update pnpm version to 10.28.2 (#1034) (ce3678e5)
- update feedback form url (#1026) (297a0d20)
- add I18n title for crowdin PRs (#1025) (71d053e0)
- Download translations from Crowdin (#1024) (fb04868d)
- update outdated dependencies with pnpm update (#995) (616e16b8)
- **i18n:** point i18n actions back to main (#1045) (2f51fdc7)

##### Continuous Integration

- update workflow to use latest from upstream (#1047) (71f479a4)
- grant pull-requests write permission for PR labeling (#1036) (6e1cdcba)

##### Documentation Changes

- update to reflect Label API limit (#955) (88605290)
- add context about the app's intent and structure (#970) (857f508c)

##### New Features

- add Query Results tab with instant query table view (#865) (#910) (c9fa9535)

##### Bug Fixes

- make logs-drilldown volume path configurable for git worktrees (#1062) (58778a9d)
- increase grafana-scopes-gmd healthcheck timings to reduce CI flakiness (#1014) (1ecc258a)
- **sidebar:** avoid empty-label option in Group by labels on first render (#1044) (1a5e06cc)
- **a11y:**
  - Support WCAG 2.1 Level A 2.4.3 Focus Order (#1046) (49be0829)
  - add consistent help controls to Onboarding and ErrorView (#1042) (a3b3c049)
  - add aria-label to search inputs for WCAG 3.3.2 compliance (#1027) (9905f863)
  - add aria-labels and improve descriptions for WCAG 2.4.6 (#998) (432386c2)
  - add aria-label and aria-expanded for WCAG 4.1.2 compliance (#1015) (bf8ec866)
  - include visible text in aria-label for text-based sidebar button (#984) (9bf1f155)
  - add aria-label to Prometheus function config radio inputs (#996) (1dc5061c)
  - associate label with Hide empty toggle switch (#986) (3c9e438f)
- **i18n:** correct plural formatting for translations (#1033) (73f2b21b)
- **ci:** use pull_request_target to allow labeling fork PRs (#1030) (018cd67a)
- **deps:** resolve 4 security vulnerabilities (#1031) (443cd223)

##### Other Changes

- Download translations from Crowdin (#1063) (30dde0c2)
- Download translations from Crowdin (#1061) (ee08d88e)
- Download translations from Crowdin (#1035) (255d0b0d)

##### Tests

- optimize e2e test patterns (#997) (c4000e1b)
- add tests for getMetricType and getPanelTypeForMetric functions (#1013) (c08f4a45)
- fix flaky panel assertion e2e tests (#993) (189d7b0a)

## 1.0.29

##### Chores

- **deps:**
  - Update pnpm to v10.28.2 [SECURITY] (#990) (2ddab3b7)
  - Pin mcr.microsoft.com/playwright Docker tag to 35c7d48 (#914) (c9da3f25)
  - Update dependency @grafana/plugin-e2e to v3 (#939) (2418890b)
  - Update actions/upload-artifact action to v6 (#919) (bf086f6e)
  - Update dependency sass to v1.97.3 (#916) (d2cbe54a)
  - update grafana/shared-workflows/get-vault-secrets action to v1.3.0 (#917) (709836ed)
  - Update dependency @types/node to v20.19.30 (#915) (7ebb4784)
- migrate from npm to pnpm (#957) (2bdf5944)
- Download translations from Crowdin (#975) (0a18c236)
- quick search assistant experiment (#959) (531b187f)
- migrate eslint config to `.mjs` (#962) (052ef827)
- merge eslint-plugin-jsx-a11y into main eslint config (#956) (408f2f47)
- update @grafana/create-plugin to v6.7.5 (#929) (6591e4f6)
- **i18n:** add crowdin github actions (#942) (8d6b8783)
- **eslint:** add @grafana/i18n rules (#926) (140798ec)

##### New Features

- Knowledge Graph source metrics enhancements (#958) (2201b01e)
- create alert from metric scene (#937) (8a90598a)

##### Bug Fixes

- **ci:**
  - remove double dashes (#992) (0a36e456)
  - remove extraneous `--` in bundle stats script (#991) (1e57122c)
- update i18n-extract to use i18next-cli (#987) (e0fccfc3)
- add webpack alias for @grafana/i18n to resolve pnpm module duplication (#985) (7bf7d895)

##### Refactors

- leverage disco union for improved type safety (#960) (4358c90b)

## 1.0.28

##### Chores

- add eslint-plugin-jsx-a11y and fix a11y violations (#924) (a805a40a)
- handle TODOs (#864) (26615aa9)
- add @grafana/i18n (#868) (86af4387)
- Remove investigations (#902) (8ae002f3)
- **deps:**
  - Update docker.io/prom/prometheus Docker tag to v3.8.1 (#838) (9fb8c24d)
  - Update dependency @prometheus-io/lezer-promql to ^0.308.0 (#877) (d738973a)

##### Continuous Integration

- upgrade shared workflows dependency (#909) (f362aa6f)

##### New Features

- mini drilldown grafana assistant navigation integration (#899) (404db242)
- assistant quicksearch integration to ask a question (#908) (0721bcce)

##### Bug Fixes

- bump @remix-run/router (#912) (a508afe5)
- group by utf8 label (#906) (77d6b227)

## 1.0.27

##### Chores

- adds "Resolves <link to issue>" so github automatically resolves issues (#895) (0e4d8765)

##### Bug Fixes

- **cve:** update qs subdependency (#900) (4f8fbb5f)
- **OpenFeature:** gracefully degrade when OFREP endpoint is unavailable (#898) (9f7a7145)

## 1.0.26

##### Chores

- replace hardcoded constant with enum (#890) (fecb8ebd)
- add OpenFeature context to sidebar analytics (#893) (15980697)
- use PluginExtensionPoints constant from @grafana/data (#874) (648b4160)
- add `openFeature` context (#891) (fb7d6934)

##### Continuous Integration

- bump shared workflows to `4.3.0` (#885) (8ec2aafc)

##### New Features

- implement the tree filter experiment with open feature (#892) (33594f07)
- init OpenFeature flag evaluations (#886) (7d68f7bf)
- assistant integration fast follow (#888) (caeed347)

## 1.0.25

##### Chores

- **deps:** Update dependency @types/node to v20.19.25 (#875) (a2a56193)

##### New Features

- **assistant:** add entry point to grafana assistant from metric scene (#883) (2f44ce5f)
- add exposed component for Knowledge Graph source metrics (#873) (120ff2d6)

##### Bug Fixes

- handle non-error object with `message` (#879) (0a92be94)

## 1.0.24

##### Chores

- bump playwright to v1.57.0 (#869) (43d070ea)
- add renovate.json (#859) (2bcf0f8b)

##### Bug Fixes

- manually revert lazy loading promql parser (#867) (76a733a9)

## 1.0.23

##### Chores

- **deps:** update dependency @grafana/faro-web-sdk to v2.0.2 (#854) (be2772dc)
- playwright only screenshot major versions (#860) (161ba87c)
- bump js-yaml from 3.14.1 to 3.14.2 (#857) (c6b07868)
- bump glob from 10.4.5 to 11.1.0 in the npm_and_yarn group across 1 directory (#855) (a2c8711c)

##### New Features

- **filters:** simple tree filter for prefix filters (#858) (750af7cd)

##### Bug Fixes

- **deps:** update dependency @bsull/augurs to ^0.10.0 (#842) (d88b79e0)

##### Tests

- loosen up playwright screenshot version check (#826) (d2b36b72)

## 1.0.22

## 1.0.21

##### Chores

- rm pre-version script check (#844) (bb4155ee)
- **deps:**
  - update dependency eslint-config-prettier to v8.10.2 (#833) (570048e3)
  - update dependency @types/node to v20.19.24 (#832) (cad8a0e3)
  - update dependency webpack to v5.102.1 (#837) (716ca1ad)
  - update dependency @grafana/assistant to v0.1.3 (#831) (8b75b59f)
  - update dependency @grafana/scenes to v6.42.2 (#834) (15cf1df3)
  - update dependency @grafana/tsconfig to v2.0.1 (#825) (05949515)
  - update dependency typescript to v5.9.3 (#817) (de5ed58e)
  - update dependency @swc/core to v1.14.0 (#812) (d2b54f48)
  - update dependency sass to v1.93.3 (#815) (56dbac3e)
  - update dependency leven to v4.1.0 (#814) (0543e672)
  - pin dependencies (#785) (c8b31460)

##### New Features

- add breadcrumbs (#810) (12cc8fa4)
- **MetricsList:** Remove configure Prometheus function button (#821) (833a4fba)

##### Bug Fixes

- update query with duplicate utf-8 metric names (#839) (fa366df7)
- **Breakdown:** Fix missing panel data (#828) (fb277012)
- **Sidebar:**
  - Remove extra space and border radius (#823) (bfc38b7e)
- **PluginInfo:** Fix missing Prometheus info (#822) (baa5fbb3)

## v1.0.20

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.20>

## v1.0.19

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.19>

## v1.0.18

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.18>

## v1.0.17

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.17>

## v1.0.16

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.16>

## v1.0.15

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.15>

## v1.0.14

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.14>

## v1.0.13

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.13>

## v1.0.12

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.12>

## v1.0.11

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.11>

## v1.0.10

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.10>

## v1.0.9

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.9>

## v1.0.8

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.8>

## v1.0.7

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.7>

## v1.0.6

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.6>

## v1.0.5

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.5>

## v1.0.4

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.4>

## v1.0.3

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.3-corrected>

## v1.0.2

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.2>

## v1.0.2-0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.2-0>

## 1.0.1

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.1>

## 1.0.0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0>

## 1.0.0-9

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-9>

## 1.0.0-8

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-8>

## 1.0.0-7

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-7>

## 1.0.0-6

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-6>

## 1.0.0-5

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-5>

## 1.0.0-4

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-4>

## 1.0.0-3

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-3>

## 1.0.0-2

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-2>

## 1.0.0-1

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-1>

## 1.0.0-0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-0>

## 0.1.0

Initial release.
